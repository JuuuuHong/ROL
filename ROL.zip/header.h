#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <Windows.h>
#pragma comment (lib, "winmm.lib")
#include <mmsystem.h>;
#include <process.h>
#include <mysql.h>


/////////////////////////

static cnt = 0;